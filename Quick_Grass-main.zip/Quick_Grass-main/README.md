# Quick_Grass

Hi there, this is a cleaned up version of the source code for my video [How do Major Video Games Render Grass?](https://youtu.be/bp7REZBV4P4)

If you're not already a subscriber, check out my channel: [SimonDev](https://www.youtube.com/channel/UCEwhtpXrg5MmwlH04ANpL8A)

It's an implementation based on the GDC presentation for [Ghost of Tsushima's grass](https://www.gdcvault.com/play/1027033/Advanced-Graphics-Summit-Procedural-Grass)


If you'd like to help choose the next video, consider support me on [Patreon](https://www.patreon.com/simondevyt)


Lastly, this is released under the MIT license, so do whatever you want. If you do happen to use it in a project, I'd appreciate a shout-out or support, although you're under no obligation to do so.

Cheers