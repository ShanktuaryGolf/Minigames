export const render_order = (() => {
  return {
    DEFAULT: 0,
    DECALS: 1,
    SHIELDS: 2,
    PARTICLES: 3,
  };
})();